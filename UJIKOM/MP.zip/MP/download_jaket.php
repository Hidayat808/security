<?php
/**
 * Download Khusus Gambar Jaket Denim
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>🔄 Download Khusus: Jaket Denim</h1>";
echo "<hr>";

$uploadDir = __DIR__ . '/uploads/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

$id = 'PRD00004';
$filename = $id . '.jpg';
$fullPath = $uploadDir . $filename;

// Multiple URL untuk Jaket Denim
$urls = [
    'https://images.unsplash.com/photo-1544923408-75d5f20e97d0?w=400&h=400&fit=crop&crop=center',
    'https://images.pexels.com/photos/2467288/pexels-photo-2467288.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
    'https://picsum.photos/400/400?random=4',
    'https://via.placeholder.com/400x400/34495E/FFFFFF?text=Jaket+Denim'
];

echo "<h3>Mencoba mendownload Jaket Denim...</h3>";

$success = false;
foreach ($urls as $index => $url) {
    echo "<p>🔄 Mencoba URL " . ($index + 1) . ": " . htmlspecialchars($url) . "</p>";
    
    try {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
        
        $data = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
        curl_close($ch);
        
        echo "HTTP Code: $httpCode, Size: " . strlen($data) . " bytes<br>";
        
        if ($httpCode == 200 && $data && strlen($data) > 500) {
            // Cek apakah ini gambar
            if (strpos($contentType, 'image') !== false || strpos($contentType, 'jpeg') !== false) {
                file_put_contents($fullPath, $data);
                echo "<p style='color:green'>✅ Berhasil download dari URL " . ($index + 1) . "</p>";
                $success = true;
                break;
            }
        }
    } catch (Exception $e) {
        echo "<p style='color:red'>Error: " . $e->getMessage() . "</p>";
    }
}

if (!$success) {
    echo "<h3>Membuat placeholder untuk Jaket Denim...</h3>";
    
    if (extension_loaded('gd')) {
        $image = imagecreatetruecolor(400, 400);
        
        // Warna denim
        $bgColor = imagecolorallocate($image, 52, 73, 94);
        imagefill($image, 0, 0, $bgColor);
        
        // Warna teks
        $white = imagecolorallocate($image, 255, 255, 255);
        $gray = imagecolorallocate($image, 150, 150, 150);
        
        // Pola denim
        for ($i = 0; $i < 10; $i++) {
            $x1 = rand(0, 400);
            $y1 = rand(0, 400);
            $x2 = rand(0, 400);
            $y2 = rand(0, 400);
            imageline($image, $x1, $y1, $x2, $y2, $gray);
        }
        
        // Teks
        $fontSize = 5;
        $text = "Jaket Denim";
        $textWidth = imagefontwidth($fontSize) * strlen($text);
        $x = (400 - $textWidth) / 2;
        $y = (400 - imagefontheight($fontSize)) / 2 - 20;
        imagestring($image, $fontSize, $x, $y, $text, $white);
        
        $textId = "ID: PRD00004";
        $textWidth = imagefontwidth($fontSize) * strlen($textId);
        $x = (400 - $textWidth) / 2;
        imagestring($image, $fontSize, $x, $y + 30, $textId, $white);
        
        imagejpeg($image, $fullPath, 90);
        imagedestroy($image);
        
        echo "<p style='color:green'>✅ Placeholder berhasil dibuat</p>";
        $success = true;
    }
}

// Update database
if ($success) {
    try {
        require_once __DIR__ . '/config/koneksi.php';
        $stmt = $pdo->prepare("UPDATE produk SET foto = ? WHERE id_produk = ?");
        $stmt->execute(['PRD00004.jpg', 'PRD00004']);
        echo "<p style='color:green'>✅ Database updated: PRD00004 -> PRD00004.jpg</p>";
    } catch (Exception $e) {
        echo "<p style='color:red'>❌ Gagal update database: " . $e->getMessage() . "</p>";
    }
}

echo "<hr>";
echo "<h3>Hasil:</h3>";

if (file_exists($fullPath) && filesize($fullPath) > 1000) {
    echo "<p style='color:green'>✅ File gambar berhasil dibuat!</p>";
    echo "<img src='uploads/PRD00004.jpg' style='max-width:300px;border:1px solid #ddd;border-radius:5px;'>";
} else {
    echo "<p style='color:red'>❌ File gambar gagal dibuat</p>";
}

echo "<br><br>";
echo "<a href='pembeli/index.php' style='display:inline-block;padding:10px 20px;background:#28a745;color:white;text-decoration:none;border-radius:5px;'>🛍️ Lihat Toko</a>";
echo "&nbsp;";
echo "<a href='setup_images.php' style='display:inline-block;padding:10px 20px;background:#667eea;color:white;text-decoration:none;border-radius:5px;'>🔄 Setup Ulang</a>";
?>
<?php
/**
 * Koneksi Database
 * Menggunakan PDO untuk keamanan dan fleksibilitas
 */

$host = 'localhost';
$dbname = 'db_marketplace';
$username = 'root';
$password = '';

try {
    // Buat koneksi PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    
    // Set mode error ke exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Set default fetch mode ke associative array
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
    // Set waktu zona
    $pdo->exec("SET time_zone = '+07:00'");
    
} catch(PDOException $e) {
    // Tampilkan error jika koneksi gagal
    die("Koneksi database gagal: " . $e->getMessage());
}

/**
 * Fungsi untuk upload file gambar
 */
function uploadFile($file, $targetDir = '../uploads/') {
    if ($file['error'] === 0) {
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        
        if (!in_array(strtolower($ext), $allowed)) {
            return ['success' => false, 'message' => 'Format file tidak diizinkan'];
        }
        
        $filename = time() . '_' . uniqid() . '.' . $ext;
        $targetPath = $targetDir . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $targetPath)) {
            return ['success' => true, 'filename' => $filename];
        }
    }
    return ['success' => false, 'message' => 'Gagal upload file'];
}
?>
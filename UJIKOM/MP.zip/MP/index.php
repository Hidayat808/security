<?php
/**
 * Halaman Utama - Redirect ke halaman pembeli
 */
header('Location: pembeli/index.php');
exit();
?>
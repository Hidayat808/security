<?php
/**
 * Logout Admin
 * Menghapus semua session dan redirect ke login
 */

session_start();
session_destroy();
header('Location: login.php');
exit();
?>  
<?php
/**
 * Daftar Pesanan
 * Menampilkan semua pesanan dari pembeli
 */

session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

require_once '../config/koneksi.php';

// Ambil semua pesanan
$pesanan = $pdo->query("
    SELECT p.*, pr.nama_produk, pr.harga as harga_satuan
    FROM pesanan p 
    LEFT JOIN produk pr ON p.id_produk = pr.id_produk 
    ORDER BY p.tanggal_pesan DESC
")->fetchAll();

// Statistik pesanan
$totalPesanan = count($pesanan);
$totalPendapatan = $pdo->query("SELECT SUM(total_harga) FROM pesanan")->fetchColumn() ?: 0;
$pesananPending = $pdo->query("SELECT COUNT(*) FROM pesanan WHERE status = 'pending'")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Pesanan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#"><i class="fas fa-store me-2"></i>Admin Panel</a>
        <div class="navbar-nav ms-auto">
            <span class="navbar-text text-white me-3">
                <i class="fas fa-user me-1"></i><?= htmlspecialchars($_SESSION['admin_name']) ?>
            </span>
            <a href="logout.php" class="btn btn-danger btn-sm">
                <i class="fas fa-sign-out-alt me-1"></i>Logout
            </a>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3">
            <div class="list-group">
                <a href="dashboard.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-home me-2"></i>Dashboard
                </a>
                <a href="kategori.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-tags me-2"></i>Kategori
                </a>
                <a href="produk.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-box me-2"></i>Produk
                </a>
                <a href="stok.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-warehouse me-2"></i>Stok
                </a>
                <a href="pesanan.php" class="list-group-item list-group-item-action active">
                    <i class="fas fa-shopping-cart me-2"></i>Pesanan
                </a>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9">
            <h4><i class="fas fa-shopping-cart me-2"></i>Daftar Pesanan</h4>
            <hr>

            <!-- Statistik -->
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="card bg-primary text-white">
                        <div class="card-body">
                            <h6 class="card-subtitle mb-2 text-white-50">Total Pesanan</h6>
                            <h3 class="card-title mb-0"><?= $totalPesanan ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card bg-success text-white">
                        <div class="card-body">
                            <h6 class="card-subtitle mb-2 text-white-50">Total Pendapatan</h6>
                            <h3 class="card-title mb-0">Rp <?= number_format($totalPendapatan, 0, ',', '.') ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card bg-warning text-white">
                        <div class="card-body">
                            <h6 class="card-subtitle mb-2 text-white-50">Pesanan Pending</h6>
                            <h3 class="card-title mb-0"><?= $pesananPending ?></h3>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Daftar Pesanan -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-list me-2"></i>Semua Pesanan</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Pembeli</th>
                                    <th>No HP</th>
                                    <th>Produk</th>
                                    <th>Jumlah</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th>Tanggal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($pesanan) > 0): ?>
                                    <?php foreach ($pesanan as $i => $p): ?>
                                        <tr>
                                            <td><?= $i + 1 ?></td>
                                            <td><?= htmlspecialchars($p['nama_pembeli']) ?></td>
                                            <td><?= htmlspecialchars($p['no_hp']) ?></td>
                                            <td><?= htmlspecialchars($p['nama_produk'] ?? 'Produk dihapus') ?></td>
                                            <td><?= $p['jumlah'] ?></td>
                                            <td>Rp <?= number_format($p['total_harga'], 0, ',', '.') ?></td>
                                            <td>
                                                <span class="badge bg-<?= 
                                                    $p['status'] == 'completed' ? 'success' : 
                                                    ($p['status'] == 'process' ? 'info' : 
                                                    ($p['status'] == 'shipped' ? 'primary' : 
                                                    ($p['status'] == 'cancelled' ? 'danger' : 'warning'))) 
                                                ?>">
                                                    <?= ucfirst($p['status']) ?>
                                                </span>
                                            </td>
                                            <td><?= date('d/m/Y H:i', strtotime($p['tanggal_pesan'])) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8" class="text-center py-3">
                                            <i class="fas fa-inbox me-2"></i>Belum ada pesanan
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
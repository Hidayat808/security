<?php
/**
 * Manajemen Kategori
 * CRUD untuk kategori produk
 */

session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

require_once '../config/koneksi.php';

// Tambah Kategori
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah'])) {
    $nama = trim($_POST['nama_kategori']);
    if (!empty($nama)) {
        // Generate ID kategori: KTG + 3 digit angka
        $id = 'KTG' . str_pad(rand(1, 999), 3, '0', STR_PAD_LEFT);
        
        // Cek duplikasi ID
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM kategori WHERE id_kategori = ?");
        $stmt->execute([$id]);
        while ($stmt->fetchColumn() > 0) {
            $id = 'KTG' . str_pad(rand(1, 999), 3, '0', STR_PAD_LEFT);
            $stmt->execute([$id]);
        }
        
        $stmt = $pdo->prepare("INSERT INTO kategori (id_kategori, nama_kategori) VALUES (?, ?)");
        $stmt->execute([$id, $nama]);
        $_SESSION['success'] = 'Kategori berhasil ditambahkan!';
    } else {
        $_SESSION['error'] = 'Nama kategori tidak boleh kosong!';
    }
    header('Location: kategori.php');
    exit();
}

// Hapus Kategori
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    // Cek apakah kategori digunakan oleh produk
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM produk WHERE id_kategori = ?");
    $stmt->execute([$id]);
    if ($stmt->fetchColumn() > 0) {
        $_SESSION['error'] = 'Kategori tidak bisa dihapus karena masih digunakan oleh produk!';
    } else {
        $stmt = $pdo->prepare("DELETE FROM kategori WHERE id_kategori = ?");
        $stmt->execute([$id]);
        $_SESSION['success'] = 'Kategori berhasil dihapus!';
    }
    header('Location: kategori.php');
    exit();
}

// Edit Kategori
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit'])) {
    $id = $_POST['id_kategori'];
    $nama = trim($_POST['nama_kategori']);
    if (!empty($nama)) {
        $stmt = $pdo->prepare("UPDATE kategori SET nama_kategori = ? WHERE id_kategori = ?");
        $stmt->execute([$nama, $id]);
        $_SESSION['success'] = 'Kategori berhasil diupdate!';
    } else {
        $_SESSION['error'] = 'Nama kategori tidak boleh kosong!';
    }
    header('Location: kategori.php');
    exit();
}

// Ambil semua kategori
$kategori = $pdo->query("SELECT * FROM kategori ORDER BY nama_kategori")->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Kategori</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#"><i class="fas fa-store me-2"></i>Admin Panel</a>
        <div class="navbar-nav ms-auto">
            <span class="navbar-text text-white me-3">
                <i class="fas fa-user me-1"></i><?= htmlspecialchars($_SESSION['admin_name']) ?>
            </span>
            <a href="logout.php" class="btn btn-danger btn-sm">
                <i class="fas fa-sign-out-alt me-1"></i>Logout
            </a>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3">
            <div class="list-group">
                <a href="dashboard.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-home me-2"></i>Dashboard
                </a>
                <a href="kategori.php" class="list-group-item list-group-item-action active">
                    <i class="fas fa-tags me-2"></i>Kategori
                </a>
                <a href="produk.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-box me-2"></i>Produk
                </a>
                <a href="stok.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-warehouse me-2"></i>Stok
                </a>
                <a href="pesanan.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-shopping-cart me-2"></i>Pesanan
                </a>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9">
            <h4><i class="fas fa-tags me-2"></i>Manajemen Kategori</h4>
            <hr>

            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="fas fa-check-circle me-2"></i><?= $_SESSION['success']; unset($_SESSION['success']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <i class="fas fa-exclamation-circle me-2"></i><?= $_SESSION['error']; unset($_SESSION['error']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Form Tambah Kategori -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-plus me-2"></i>Tambah Kategori</h5>
                </div>
                <div class="card-body">
                    <form action="" method="POST" class="row g-3">
                        <div class="col-md-8">
                            <input type="text" class="form-control" name="nama_kategori" 
                                   placeholder="Nama kategori..." required>
                        </div>
                        <div class="col-md-4">
                            <button type="submit" name="tambah" class="btn btn-primary w-100">
                                <i class="fas fa-save me-1"></i>Simpan
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Daftar Kategori -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-list me-2"></i>Daftar Kategori</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>ID Kategori</th>
                                    <th>Nama Kategori</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($kategori) > 0): ?>
                                    <?php foreach ($kategori as $i => $k): ?>
                                        <tr>
                                            <td><?= $i + 1 ?></td>
                                            <td><code><?= $k['id_kategori'] ?></code></td>
                                            <td><?= htmlspecialchars($k['nama_kategori']) ?></td>
                                            <td>
                                                <button class="btn btn-warning btn-sm" 
                                                        data-bs-toggle="modal" 
                                                        data-bs-target="#editModal<?= $k['id_kategori'] ?>">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <a href="?hapus=<?= $k['id_kategori'] ?>" 
                                                   class="btn btn-danger btn-sm" 
                                                   onclick="return confirm('Yakin ingin menghapus kategori ini?')">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>

                                        <!-- Modal Edit -->
                                        <div class="modal fade" id="editModal<?= $k['id_kategori'] ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <form action="" method="POST">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">
                                                                <i class="fas fa-edit me-2"></i>Edit Kategori
                                                            </h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <input type="hidden" name="id_kategori" value="<?= $k['id_kategori'] ?>">
                                                            <label class="form-label">Nama Kategori</label>
                                                            <input type="text" class="form-control" 
                                                                   name="nama_kategori" 
                                                                   value="<?= htmlspecialchars($k['nama_kategori']) ?>" 
                                                                   required>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                            <button type="submit" name="edit" class="btn btn-primary">
                                                                <i class="fas fa-save me-1"></i>Simpan
                                                            </button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4" class="text-center py-3">
                                            <i class="fas fa-inbox me-2"></i>Belum ada kategori
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
/**
 * Manajemen Stok
 * Penambahan stok manual oleh admin
 */

session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

require_once '../config/koneksi.php';

// Tambah Stok
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah_stok'])) {
    $id_produk = $_POST['id_produk'];
    $stok_tambah = (int)$_POST['stok_tambah'];
    
    if ($stok_tambah > 0) {
        $stmt = $pdo->prepare("UPDATE produk SET stok = stok + ? WHERE id_produk = ?");
        $stmt->execute([$stok_tambah, $id_produk]);
        $_SESSION['success'] = 'Stok berhasil ditambahkan!';
    } else {
        $_SESSION['error'] = 'Jumlah stok harus lebih dari 0!';
    }
    header('Location: stok.php');
    exit();
}

// Ambil semua produk
$produk = $pdo->query("
    SELECT p.*, k.nama_kategori 
    FROM produk p 
    LEFT JOIN kategori k ON p.id_kategori = k.id_kategori 
    ORDER BY p.nama_produk
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Stok</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#"><i class="fas fa-store me-2"></i>Admin Panel</a>
        <div class="navbar-nav ms-auto">
            <span class="navbar-text text-white me-3">
                <i class="fas fa-user me-1"></i><?= htmlspecialchars($_SESSION['admin_name']) ?>
            </span>
            <a href="logout.php" class="btn btn-danger btn-sm">
                <i class="fas fa-sign-out-alt me-1"></i>Logout
            </a>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3">
            <div class="list-group">
                <a href="dashboard.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-home me-2"></i>Dashboard
                </a>
                <a href="kategori.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-tags me-2"></i>Kategori
                </a>
                <a href="produk.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-box me-2"></i>Produk
                </a>
                <a href="stok.php" class="list-group-item list-group-item-action active">
                    <i class="fas fa-warehouse me-2"></i>Stok
                </a>
                <a href="pesanan.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-shopping-cart me-2"></i>Pesanan
                </a>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9">
            <h4><i class="fas fa-warehouse me-2"></i>Manajemen Stok</h4>
            <hr>

            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="fas fa-check-circle me-2"></i><?= $_SESSION['success']; unset($_SESSION['success']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <i class="fas fa-exclamation-circle me-2"></i><?= $_SESSION['error']; unset($_SESSION['error']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Daftar Produk dengan Stok -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-list me-2"></i>Daftar Produk</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Nama Produk</th>
                                    <th>Kategori</th>
                                    <th>Stok Saat Ini</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($produk) > 0): ?>
                                    <?php foreach ($produk as $i => $p): ?>
                                        <tr>
                                            <td><?= $i + 1 ?></td>
                                            <td><?= htmlspecialchars($p['nama_produk']) ?></td>
                                            <td><?= htmlspecialchars($p['nama_kategori'] ?? '-') ?></td>
                                            <td>
                                                <span class="badge bg-<?= $p['stok'] <= 5 ? 'danger' : ($p['stok'] <= 10 ? 'warning' : 'success') ?>">
                                                    <?= $p['stok'] ?>
                                                </span>
                                            </td>
                                            <td>
                                                <button class="btn btn-primary btn-sm" 
                                                        data-bs-toggle="modal" 
                                                        data-bs-target="#stokModal<?= $p['id_produk'] ?>">
                                                    <i class="fas fa-plus me-1"></i>Tambah Stok
                                                </button>
                                            </td>
                                        </tr>

                                        <!-- Modal Tambah Stok -->
                                        <div class="modal fade" id="stokModal<?= $p['id_produk'] ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <form action="" method="POST">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">
                                                                <i class="fas fa-plus-circle me-2"></i>Tambah Stok
                                                            </h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <input type="hidden" name="id_produk" value="<?= $p['id_produk'] ?>">
                                                            <p>
                                                                <strong><?= htmlspecialchars($p['nama_produk']) ?></strong><br>
                                                                Stok saat ini: <span class="badge bg-secondary"><?= $p['stok'] ?></span>
                                                            </p>
                                                            <label class="form-label">Jumlah ditambahkan <span class="text-danger">*</span></label>
                                                            <input type="number" class="form-control" 
                                                                   name="stok_tambah" min="1" required>
                                                            <small class="text-muted">Masukkan jumlah stok yang ingin ditambahkan</small>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                            <button type="submit" name="tambah_stok" class="btn btn-primary">
                                                                <i class="fas fa-save me-1"></i>Tambah
                                                            </button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5" class="text-center py-3">
                                            <i class="fas fa-inbox me-2"></i>Belum ada produk
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
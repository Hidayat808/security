<?php
/**
 * Manajemen Produk
 * CRUD untuk produk marketplace
 */

session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

require_once '../config/koneksi.php';

// Ambil semua kategori untuk dropdown
$kategori = $pdo->query("SELECT * FROM kategori ORDER BY nama_kategori")->fetchAll();

// Tambah Produk
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah'])) {
    $id = 'PRD' . str_pad(rand(1, 99999), 5, '0', STR_PAD_LEFT);
    
    // Cek duplikasi ID
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM produk WHERE id_produk = ?");
    $stmt->execute([$id]);
    while ($stmt->fetchColumn() > 0) {
        $id = 'PRD' . str_pad(rand(1, 99999), 5, '0', STR_PAD_LEFT);
        $stmt->execute([$id]);
    }
    
    // Upload foto
    $foto = '';
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === 0) {
        $result = uploadFile($_FILES['foto']);
        if ($result['success']) {
            $foto = $result['filename'];
        }
    }
    
    $stmt = $pdo->prepare("
        INSERT INTO produk (id_produk, nama_produk, id_kategori, deskripsi, harga, stok, foto) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $id,
        $_POST['nama_produk'],
        $_POST['id_kategori'] ?: null,
        $_POST['deskripsi'],
        $_POST['harga'],
        $_POST['stok'],
        $foto
    ]);
    
    $_SESSION['success'] = 'Produk berhasil ditambahkan!';
    header('Location: produk.php');
    exit();
}

// Hapus Produk
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    
    // Ambil nama foto untuk dihapus
    $stmt = $pdo->prepare("SELECT foto FROM produk WHERE id_produk = ?");
    $stmt->execute([$id]);
    $foto = $stmt->fetchColumn();
    
    if ($foto && file_exists("../uploads/" . $foto)) {
        unlink("../uploads/" . $foto);
    }
    
    $stmt = $pdo->prepare("DELETE FROM produk WHERE id_produk = ?");
    $stmt->execute([$id]);
    $_SESSION['success'] = 'Produk berhasil dihapus!';
    header('Location: produk.php');
    exit();
}

// Edit Produk
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit'])) {
    $id = $_POST['id_produk'];
    
    $stmt = $pdo->prepare("
        UPDATE produk 
        SET nama_produk = ?, id_kategori = ?, deskripsi = ?, harga = ?, stok = ? 
        WHERE id_produk = ?
    ");
    $stmt->execute([
        $_POST['nama_produk'],
        $_POST['id_kategori'] ?: null,
        $_POST['deskripsi'],
        $_POST['harga'],
        $_POST['stok'],
        $id
    ]);
    
    $_SESSION['success'] = 'Produk berhasil diupdate!';
    header('Location: produk.php');
    exit();
}

// Ambil semua produk
$produk = $pdo->query("
    SELECT p.*, k.nama_kategori 
    FROM produk p 
    LEFT JOIN kategori k ON p.id_kategori = k.id_kategori 
    ORDER BY p.created_at DESC
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Produk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#"><i class="fas fa-store me-2"></i>Admin Panel</a>
        <div class="navbar-nav ms-auto">
            <span class="navbar-text text-white me-3">
                <i class="fas fa-user me-1"></i><?= htmlspecialchars($_SESSION['admin_name']) ?>
            </span>
            <a href="logout.php" class="btn btn-danger btn-sm">
                <i class="fas fa-sign-out-alt me-1"></i>Logout
            </a>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3">
            <div class="list-group">
                <a href="dashboard.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-home me-2"></i>Dashboard
                </a>
                <a href="kategori.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-tags me-2"></i>Kategori
                </a>
                <a href="produk.php" class="list-group-item list-group-item-action active">
                    <i class="fas fa-box me-2"></i>Produk
                </a>
                <a href="stok.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-warehouse me-2"></i>Stok
                </a>
                <a href="pesanan.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-shopping-cart me-2"></i>Pesanan
                </a>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9">
            <div class="d-flex justify-content-between align-items-center">
                <h4><i class="fas fa-box me-2"></i>Manajemen Produk</h4>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#tambahModal">
                    <i class="fas fa-plus me-1"></i>Tambah Produk
                </button>
            </div>
            <hr>

            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="fas fa-check-circle me-2"></i><?= $_SESSION['success']; unset($_SESSION['success']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Daftar Produk -->
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>ID</th>
                                    <th>Foto</th>
                                    <th>Nama</th>
                                    <th>Kategori</th>
                                    <th>Harga</th>
                                    <th>Stok</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($produk) > 0): ?>
                                    <?php foreach ($produk as $i => $p): ?>
                                        <tr>
                                            <td><?= $i + 1 ?></td>
                                            <td><code><?= $p['id_produk'] ?></code></td>
                                            <td>
                                                <?php if ($p['foto'] && file_exists("../uploads/" . $p['foto'])): ?>
                                                    <img src="../uploads/<?= $p['foto'] ?>" width="50" height="50" 
                                                         class="rounded" style="object-fit:cover;">
                                                <?php else: ?>
                                                    <div class="bg-light rounded text-center py-2" style="width:50px;height:50px;">
                                                        <i class="fas fa-image text-muted"></i>
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                            <td><?= htmlspecialchars($p['nama_produk']) ?></td>
                                            <td><?= htmlspecialchars($p['nama_kategori'] ?? '-') ?></td>
                                            <td>Rp <?= number_format($p['harga'], 0, ',', '.') ?></td>
                                            <td>
                                                <span class="badge bg-<?= $p['stok'] <= 5 ? 'danger' : ($p['stok'] <= 10 ? 'warning' : 'success') ?>">
                                                    <?= $p['stok'] ?>
                                                </span>
                                            </td>
                                            <td>
                                                <button class="btn btn-warning btn-sm" 
                                                        data-bs-toggle="modal" 
                                                        data-bs-target="#editModal<?= $p['id_produk'] ?>">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <a href="?hapus=<?= $p['id_produk'] ?>" 
                                                   class="btn btn-danger btn-sm" 
                                                   onclick="return confirm('Yakin ingin menghapus produk ini?')">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>

                                        <!-- Modal Edit Produk -->
                                        <div class="modal fade" id="editModal<?= $p['id_produk'] ?>">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <form action="" method="POST">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">
                                                                <i class="fas fa-edit me-2"></i>Edit Produk
                                                            </h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <input type="hidden" name="id_produk" value="<?= $p['id_produk'] ?>">
                                                            <div class="row">
                                                                <div class="col-md-6 mb-3">
                                                                    <label class="form-label">Nama Produk</label>
                                                                    <input type="text" class="form-control" 
                                                                           name="nama_produk" 
                                                                           value="<?= htmlspecialchars($p['nama_produk']) ?>" 
                                                                           required>
                                                                </div>
                                                                <div class="col-md-6 mb-3">
                                                                    <label class="form-label">Kategori</label>
                                                                    <select class="form-select" name="id_kategori">
                                                                        <option value="">Tanpa Kategori</option>
                                                                        <?php foreach ($kategori as $k): ?>
                                                                            <option value="<?= $k['id_kategori'] ?>" 
                                                                                    <?= $k['id_kategori'] == $p['id_kategori'] ? 'selected' : '' ?>>
                                                                                <?= htmlspecialchars($k['nama_kategori']) ?>
                                                                            </option>
                                                                        <?php endforeach; ?>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label">Deskripsi</label>
                                                                <textarea class="form-control" name="deskripsi" rows="3"><?= htmlspecialchars($p['deskripsi'] ?? '') ?></textarea>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-md-6 mb-3">
                                                                    <label class="form-label">Harga</label>
                                                                    <input type="number" class="form-control" 
                                                                           name="harga" value="<?= $p['harga'] ?>" 
                                                                           required min="0">
                                                                </div>
                                                                <div class="col-md-6 mb-3">
                                                                    <label class="form-label">Stok</label>
                                                                    <input type="number" class="form-control" 
                                                                           name="stok" value="<?= $p['stok'] ?>" 
                                                                           required min="0">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                            <button type="submit" name="edit" class="btn btn-primary">
                                                                <i class="fas fa-save me-1"></i>Simpan
                                                            </button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8" class="text-center py-3">
                                            <i class="fas fa-inbox me-2"></i>Belum ada produk
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tambah Produk -->
<div class="modal fade" id="tambahModal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form action="" method="POST" enctype="multipart/form-data">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-plus me-2"></i>Tambah Produk</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nama Produk <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="nama_produk" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Kategori</label>
                            <select class="form-select" name="id_kategori">
                                <option value="">Tanpa Kategori</option>
                                <?php foreach ($kategori as $k): ?>
                                    <option value="<?= $k['id_kategori'] ?>">
                                        <?= htmlspecialchars($k['nama_kategori']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Deskripsi</label>
                        <textarea class="form-control" name="deskripsi" rows="3"></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Harga <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" name="harga" required min="0">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Stok <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" name="stok" required min="0">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Foto</label>
                            <input type="file" class="form-control" name="foto" accept="image/*">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="tambah" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i>Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
/**
 * Dashboard Admin
 * Menampilkan ringkasan total produk, kategori, dan pesanan
 */

session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

require_once '../config/koneksi.php';

// Ambil data statistik
$totalProduk = $pdo->query("SELECT COUNT(*) FROM produk")->fetchColumn();
$totalKategori = $pdo->query("SELECT COUNT(*) FROM kategori")->fetchColumn();
$totalPesanan = $pdo->query("SELECT COUNT(*) FROM pesanan")->fetchColumn();

// Pesanan terbaru
$pesananTerbaru = $pdo->query("
    SELECT p.*, pr.nama_produk 
    FROM pesanan p 
    LEFT JOIN produk pr ON p.id_produk = pr.id_produk 
    ORDER BY p.tanggal_pesan DESC 
    LIMIT 5
")->fetchAll();

// Produk stok menipis (<= 10)
$produkStokMenipis = $pdo->query("
    SELECT * FROM produk 
    WHERE stok <= 10 
    ORDER BY stok ASC 
    LIMIT 5
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .stat-card {
            border-radius: 12px;
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-icon {
            font-size: 40px;
            opacity: 0.3;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#">
            <i class="fas fa-store me-2"></i>Admin Panel
        </a>
        <div class="navbar-nav ms-auto">
            <span class="navbar-text text-white me-3">
                <i class="fas fa-user me-1"></i><?= htmlspecialchars($_SESSION['admin_name']) ?>
            </span>
            <a href="logout.php" class="btn btn-danger btn-sm">
                <i class="fas fa-sign-out-alt me-1"></i>Logout
            </a>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3">
            <div class="list-group">
                <a href="dashboard.php" class="list-group-item list-group-item-action active">
                    <i class="fas fa-home me-2"></i>Dashboard
                </a>
                <a href="kategori.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-tags me-2"></i>Kategori
                </a>
                <a href="produk.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-box me-2"></i>Produk
                </a>
                <a href="stok.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-warehouse me-2"></i>Stok
                </a>
                <a href="pesanan.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-shopping-cart me-2"></i>Pesanan
                </a>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9">
            <h4><i class="fas fa-chart-pie me-2"></i>Dashboard</h4>
            <hr>

            <!-- Statistik Cards -->
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="card stat-card bg-primary text-white">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-subtitle mb-2 text-white-50">Total Produk</h6>
                                    <h2 class="card-title mb-0"><?= $totalProduk ?></h2>
                                </div>
                                <div class="stat-icon">
                                    <i class="fas fa-box"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card stat-card bg-success text-white">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-subtitle mb-2 text-white-50">Total Kategori</h6>
                                    <h2 class="card-title mb-0"><?= $totalKategori ?></h2>
                                </div>
                                <div class="stat-icon">
                                    <i class="fas fa-tags"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card stat-card bg-warning text-white">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-subtitle mb-2 text-white-50">Total Pesanan</h6>
                                    <h2 class="card-title mb-0"><?= $totalPesanan ?></h2>
                                </div>
                                <div class="stat-icon">
                                    <i class="fas fa-shopping-cart"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Pesanan Terbaru -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-clock me-2"></i>Pesanan Terbaru</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Pembeli</th>
                                    <th>Produk</th>
                                    <th>Jumlah</th>
                                    <th>Total</th>
                                    <th>Tanggal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($pesananTerbaru) > 0): ?>
                                    <?php foreach ($pesananTerbaru as $p): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($p['nama_pembeli']) ?></td>
                                            <td><?= htmlspecialchars($p['nama_produk'] ?? 'Produk dihapus') ?></td>
                                            <td><?= $p['jumlah'] ?></td>
                                            <td>Rp <?= number_format($p['total_harga'], 0, ',', '.') ?></td>
                                            <td><?= date('d/m/Y H:i', strtotime($p['tanggal_pesan'])) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr><td colspan="5" class="text-center">Belum ada pesanan</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Stok Menipis -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-exclamation-triangle me-2"></i>Stok Menipis</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Produk</th>
                                    <th>Stok</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($produkStokMenipis) > 0): ?>
                                    <?php foreach ($produkStokMenipis as $p): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($p['nama_produk']) ?></td>
                                            <td><?= $p['stok'] ?></td>
                                            <td>
                                                <span class="badge bg-<?= $p['stok'] <= 5 ? 'danger' : 'warning' ?>">
                                                    <?= $p['stok'] <= 5 ? 'Segera Isi Ulang' : 'Menipis' ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr><td colspan="3" class="text-center">Semua produk memiliki stok cukup</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
/**
 * Halaman Landing Page / Beranda
 * Menampilkan katalog produk untuk pembeli dengan fitur pencarian dan filter
 */

require_once '../config/koneksi.php';

// Ambil parameter pencarian dan filter
$search = $_GET['search'] ?? '';
$filter = $_GET['kategori'] ?? '';

// Query produk dengan filter
$sql = "SELECT p.*, k.nama_kategori 
        FROM produk p 
        LEFT JOIN kategori k ON p.id_kategori = k.id_kategori 
        WHERE p.stok > 0";
$params = [];

if ($search) {
    $sql .= " AND p.nama_produk LIKE ?";
    $params[] = "%$search%";
}

if ($filter) {
    $sql .= " AND p.id_kategori = ?";
    $params[] = $filter;
}

$sql .= " ORDER BY p.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$produk = $stmt->fetchAll();

// Ambil semua kategori untuk filter
$kategori = $pdo->query("SELECT * FROM kategori ORDER BY nama_kategori")->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marketplace - Belanja Online</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .hero-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 50px 0;
            border-radius: 15px;
            margin-bottom: 30px;
        }
        .product-card {
            transition: transform 0.3s, box-shadow 0.3s;
            height: 100%;
        }
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        .product-img {
            height: 200px;
            object-fit: cover;
        }
        .price {
            font-size: 1.1rem;
            font-weight: 700;
            color: #667eea;
        }
        .btn-detail {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            color: white;
        }
        .btn-detail:hover {
            color: white;
            opacity: 0.9;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#">
            <i class="fas fa-store me-2"></i>Marketplace
        </a>
        <div class="navbar-nav ms-auto">
            <a href="../admin/login.php" class="btn btn-outline-light btn-sm">
                <i class="fas fa-user-shield me-1"></i>Login Admin
            </a>
        </div>
    </div>
</nav>

<div class="container">
    <!-- Hero Section -->
    <div class="hero-section text-center">
        <h1><i class="fas fa-shopping-bag me-3"></i>Selamat Datang di Marketplace</h1>
        <p class="lead">Temukan berbagai produk berkualitas dengan harga terbaik</p>
    </div>

    <!-- Search & Filter -->
    <div class="row mb-4">
        <div class="col-md-12">
            <form action="" method="GET" class="row g-3">
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" class="form-control" name="search" 
                               placeholder="Cari produk..." value="<?= htmlspecialchars($search) ?>">
                    </div>
                </div>
                <div class="col-md-5">
                    <select class="form-select" name="kategori">
                        <option value="">Semua Kategori</option>
                        <?php foreach ($kategori as $k): ?>
                            <option value="<?= $k['id_kategori'] ?>" 
                                    <?= $filter == $k['id_kategori'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($k['nama_kategori']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter me-1"></i>Cari
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Katalog Produk -->
    <h4 class="mb-3"><i class="fas fa-boxes me-2"></i>Katalog Produk</h4>
    <hr>

    <?php if (count($produk) > 0): ?>
        <div class="row">
            <?php foreach ($produk as $p): ?>
                <div class="col-md-3 mb-4">
                    <div class="card product-card">
                        <?php if ($p['foto'] && file_exists("../uploads/" . $p['foto'])): ?>
                            <img src="../uploads/<?= $p['foto'] ?>" class="card-img-top product-img" 
                                 alt="<?= htmlspecialchars($p['nama_produk']) ?>">
                        <?php else: ?>
                            <div class="card-img-top product-img bg-light d-flex align-items-center justify-content-center">
                                <i class="fas fa-image fa-3x text-muted"></i>
                            </div>
                        <?php endif; ?>
                        <div class="card-body">
                            <h6 class="card-title"><?= htmlspecialchars($p['nama_produk']) ?></h6>
                            <p class="text-muted small"><?= htmlspecialchars($p['nama_kategori'] ?? '-') ?></p>
                            <p class="price">Rp <?= number_format($p['harga'], 0, ',', '.') ?></p>
                            <p class="small text-muted">
                                <i class="fas fa-box me-1"></i>Stok: <?= $p['stok'] ?>
                            </p>
                            <a href="detail.php?id=<?= $p['id_produk'] ?>" class="btn btn-detail w-100">
                                <i class="fas fa-eye me-1"></i>Detail
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="text-center py-5">
            <i class="fas fa-search fa-3x text-muted mb-3"></i>
            <h5>Produk tidak ditemukan</h5>
            <p class="text-muted">Coba gunakan kata kunci lain atau reset filter</p>
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-undo me-1"></i>Reset
            </a>
        </div>
    <?php endif; ?>
</div>

<!-- Footer -->
<footer class="bg-dark text-white mt-5 py-3">
    <div class="container text-center">
        <small>&copy; <?= date('Y') ?> Marketplace. All rights reserved.</small>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
/**
 * Halaman Detail Produk
 * Menampilkan informasi lengkap produk dan form pemesanan
 */

require_once '../config/koneksi.php';

$id = $_GET['id'] ?? '';

if (empty($id)) {
    header('Location: index.php');
    exit();
}

// Ambil data produk
$stmt = $pdo->prepare("
    SELECT p.*, k.nama_kategori 
    FROM produk p 
    LEFT JOIN kategori k ON p.id_kategori = k.id_kategori 
    WHERE p.id_produk = ?
");
$stmt->execute([$id]);
$produk = $stmt->fetch();

if (!$produk) {
    header('Location: index.php');
    exit();
}

// Tampilkan pesan error jika ada
$error = $_GET['error'] ?? '';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Produk - <?= htmlspecialchars($produk['nama_produk']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .product-image {
            width: 100%;
            max-height: 500px;
            object-fit: cover;
            border-radius: 10px;
        }
        .price-large {
            font-size: 2rem;
            font-weight: 700;
            color: #667eea;
        }
        .btn-order {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            color: white;
            font-weight: 600;
            padding: 12px;
        }
        .btn-order:hover {
            color: white;
            opacity: 0.9;
        }
        .stok-badge {
            font-size: 1rem;
            padding: 8px 15px;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="index.php">
            <i class="fas fa-store me-2"></i>Marketplace
        </a>
        <div class="navbar-nav ms-auto">
            <a href="index.php" class="btn btn-light btn-sm">
                <i class="fas fa-arrow-left me-1"></i>Kembali
            </a>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="fas fa-exclamation-circle me-2"></i><?= htmlspecialchars($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <!-- Gambar Produk -->
        <div class="col-md-6">
            <?php if ($produk['foto'] && file_exists("../uploads/" . $produk['foto'])): ?>
                <img src="../uploads/<?= $produk['foto'] ?>" class="product-image" 
                     alt="<?= htmlspecialchars($produk['nama_produk']) ?>">
            <?php else: ?>
                <div class="product-image bg-light d-flex align-items-center justify-content-center">
                    <i class="fas fa-image fa-5x text-muted"></i>
                </div>
            <?php endif; ?>
        </div>

        <!-- Informasi Produk -->
        <div class="col-md-6">
            <h2><?= htmlspecialchars($produk['nama_produk']) ?></h2>
            <p class="text-muted">
                <i class="fas fa-tag me-1"></i><?= htmlspecialchars($produk['nama_kategori'] ?? 'Tanpa Kategori') ?>
            </p>
            
            <div class="price-large">Rp <?= number_format($produk['harga'], 0, ',', '.') ?></div>
            
            <div class="mt-3">
                <span class="badge bg-<?= $produk['stok'] > 0 ? 'success' : 'danger' ?> stok-badge">
                    <i class="fas fa-box me-1"></i>
                    <?= $produk['stok'] > 0 ? 'Stok: ' . $produk['stok'] : 'Stok Habis' ?>
                </span>
            </div>

            <div class="mt-3">
                <h6>Deskripsi</h6>
                <p><?= nl2br(htmlspecialchars($produk['deskripsi'] ?? 'Tidak ada deskripsi')) ?></p>
            </div>

            <hr>

            <!-- Form Pemesanan -->
            <?php if ($produk['stok'] > 0): ?>
                <div class="card border-primary">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="fas fa-shopping-cart me-2"></i>Form Pemesanan</h5>
                    </div>
                    <div class="card-body">
                        <form action="pesan.php" method="POST">
                            <input type="hidden" name="id_produk" value="<?= $produk['id_produk'] ?>">
                            
                            <div class="mb-3">
                                <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="nama_pembeli" 
                                       placeholder="Masukkan nama Anda" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Nomor HP <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="no_hp" 
                                       placeholder="Contoh: 081234567890" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Jumlah Pesan <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" name="jumlah" 
                                       min="1" max="<?= $produk['stok'] ?>" 
                                       placeholder="Maksimal <?= $produk['stok'] ?>" required>
                                <small class="text-muted">Stok tersedia: <?= $produk['stok'] ?></small>
                            </div>
                            
                            <button type="submit" class="btn btn-order w-100">
                                <i class="fas fa-check me-1"></i>Pesan Sekarang
                            </button>
                        </form>
                    </div>
                </div>
            <?php else: ?>
                <div class="alert alert-danger text-center">
                    <i class="fas fa-times-circle me-2"></i>
                    <strong>Maaf, stok produk ini sedang habis.</strong>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="bg-dark text-white mt-5 py-3">
    <div class="container text-center">
        <small>&copy; <?= date('Y') ?> Marketplace. All rights reserved.</small>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
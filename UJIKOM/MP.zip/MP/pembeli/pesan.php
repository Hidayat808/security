<?php
/**
 * Proses Pemesanan
 * Menyimpan pesanan dan mengurangi stok produk
 */

require_once '../config/koneksi.php';

// Cek method POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit();
}

// Ambil data dari form
$id_produk = $_POST['id_produk'] ?? '';
$nama = trim($_POST['nama_pembeli'] ?? '');
$hp = trim($_POST['no_hp'] ?? '');
$jumlah = (int)($_POST['jumlah'] ?? 0);

// Validasi input
if (empty($id_produk) || empty($nama) || empty($hp) || $jumlah <= 0) {
    header('Location: detail.php?id=' . $id_produk . '&error=Semua field harus diisi!');
    exit();
}

// Cek produk dan stok
$stmt = $pdo->prepare("SELECT * FROM produk WHERE id_produk = ?");
$stmt->execute([$id_produk]);
$produk = $stmt->fetch();

if (!$produk) {
    header('Location: index.php?error=Produk tidak ditemukan');
    exit();
}

if ($jumlah > $produk['stok']) {
    header('Location: detail.php?id=' . $id_produk . '&error=Stok tidak mencukupi! Tersedia ' . $produk['stok'] . ' unit');
    exit();
}

// Hitung total harga
$total = $produk['harga'] * $jumlah;

try {
    // Mulai transaksi
    $pdo->beginTransaction();
    
    // Insert pesanan
    $stmt = $pdo->prepare("
        INSERT INTO pesanan (id_produk, nama_pembeli, no_hp, jumlah, total_harga, status) 
        VALUES (?, ?, ?, ?, ?, 'pending')
    ");
    $stmt->execute([$id_produk, $nama, $hp, $jumlah, $total]);
    
    // Kurangi stok
    $stmt = $pdo->prepare("UPDATE produk SET stok = stok - ? WHERE id_produk = ?");
    $stmt->execute([$jumlah, $id_produk]);
    
    // Commit transaksi
    $pdo->commit();
    
    // Redirect dengan pesan sukses
    header('Location: index.php?success=1');
    exit();
    
} catch (PDOException $e) {
    // Rollback jika terjadi error
    $pdo->rollBack();
    header('Location: detail.php?id=' . $id_produk . '&error=Terjadi kesalahan sistem: ' . $e->getMessage());
    exit();
}
?>
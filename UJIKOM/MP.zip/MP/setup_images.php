<?php
/**
 * SETUP GAMBAR PRODUK OTOMATIS
 * File ini akan mendownload dan mengatur semua gambar produk
 * Jalankan sekali saja untuk setup awal
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('max_execution_time', 300); // 5 menit

echo "<!DOCTYPE html>
<html>
<head>
    <title>Setup Gambar Produk Otomatis</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 900px; margin: 50px auto; padding: 20px; background: #f5f5f5; }
        .container { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h1 { color: #333; border-bottom: 3px solid #667eea; padding-bottom: 10px; }
        .success { color: green; }
        .error { color: red; }
        .info { color: #667eea; }
        .step { background: #f8f9fa; padding: 15px; margin: 10px 0; border-radius: 5px; border-left: 4px solid #667eea; }
        .progress-bar { width: 100%; background: #e9ecef; border-radius: 5px; overflow: hidden; margin: 10px 0; }
        .progress-fill { height: 30px; background: linear-gradient(90deg, #667eea, #764ba2); color: white; text-align: center; line-height: 30px; transition: width 0.5s; }
        .product-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 15px; margin: 20px 0; }
        .product-item { border: 1px solid #ddd; padding: 10px; border-radius: 5px; text-align: center; background: white; }
        .product-item img { width: 100px; height: 100px; object-fit: cover; border-radius: 5px; }
        .product-item .name { font-size: 12px; margin-top: 5px; color: #666; }
        .product-item .id { font-size: 11px; color: #999; }
        .btn { display: inline-block; padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; margin: 5px; }
        .btn:hover { background: #5a6fd6; }
        .btn-success { background: #28a745; }
        .btn-success:hover { background: #218838; }
        .btn-warning { background: #ffc107; color: #333; }
        .btn-warning:hover { background: #e0a800; }
        pre { background: #f4f4f4; padding: 15px; border-radius: 5px; overflow-x: auto; }
    </style>
</head>
<body>
<div class='container'>";

echo "<h1>🖼️ Setup Gambar Produk Otomatis</h1>";
echo "<p>Script ini akan mengunduh dan mengatur semua gambar produk untuk aplikasi Marketplace.</p>";

// ============================================
// STEP 1: Cek dan Buat Folder Uploads
// ============================================
echo "<div class='step'>";
echo "<h3>📁 Step 1: Persiapan Folder Uploads</h3>";

$uploadDir = __DIR__ . '/uploads/';
if (!is_dir($uploadDir)) {
    if (mkdir($uploadDir, 0777, true)) {
        echo "<p class='success'>✅ Folder uploads berhasil dibuat di: <code>$uploadDir</code></p>";
    } else {
        echo "<p class='error'>❌ Gagal membuat folder uploads. Buat manual dengan permission 777.</p>";
        die();
    }
} else {
    echo "<p class='success'>✅ Folder uploads sudah ada</p>";
}

// Cek writable
if (is_writable($uploadDir)) {
    echo "<p class='success'>✅ Folder uploads dapat ditulis</p>";
} else {
    echo "<p class='error'>❌ Folder uploads tidak dapat ditulis. Ubah permission menjadi 777.</p>";
    die();
}
echo "</div>";

// ============================================
// STEP 2: Cek Koneksi Database
// ============================================
echo "<div class='step'>";
echo "<h3>🗄️ Step 2: Cek Koneksi Database</h3>";

try {
    require_once __DIR__ . '/config/koneksi.php';
    echo "<p class='success'>✅ Koneksi database berhasil</p>";
    
    // Cek tabel produk
    $stmt = $pdo->query("SELECT COUNT(*) FROM produk");
    $totalProduk = $stmt->fetchColumn();
    echo "<p class='success'>✅ Total produk: $totalProduk</p>";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Koneksi database gagal: " . $e->getMessage() . "</p>";
    echo "<p>Pastikan file <code>config/koneksi.php</code> sudah benar.</p>";
    die();
}
echo "</div>";

// ============================================
// STEP 3: Download Gambar
// ============================================
echo "<div class='step'>";
echo "<h3>📥 Step 3: Download Gambar Produk</h3>";

// Daftar produk dengan URL gambar
$products = [
    [
        'id' => 'PRD00001',
        'name' => 'Smartphone Galaxy A54',
        'url' => 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400&h=400&fit=crop&crop=center',
        'fallback' => 'https://via.placeholder.com/400x400/4A90D9/FFFFFF?text=Smartphone+Galaxy+A54'
    ],
    [
        'id' => 'PRD00002',
        'name' => 'Laptop Asus Vivobook',
        'url' => 'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=400&h=400&fit=crop&crop=center',
        'fallback' => 'https://via.placeholder.com/400x400/2C3E50/FFFFFF?text=Laptop+Asus+Vivobook'
    ],
    [
        'id' => 'PRD00003',
        'name' => 'Kaos Polos Premium',
        'url' => 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=400&fit=crop&crop=center',
        'fallback' => 'https://via.placeholder.com/400x400/E74C3C/FFFFFF?text=Kaos+Polos+Premium'
    ],
    [
        'id' => 'PRD00004',
        'name' => 'Jaket Denim',
        'url' => 'https://images.unsplash.com/photo-1544923408-75d5f20e97d0?w=400&h=400&fit=crop&crop=center',
        'fallback' => 'https://via.placeholder.com/400x400/34495E/FFFFFF?text=Jaket+Denim'
    ],
    [
        'id' => 'PRD00005',
        'name' => 'Kopi Arabica Premium',
        'url' => 'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=400&h=400&fit=crop&crop=center',
        'fallback' => 'https://via.placeholder.com/400x400/8B4513/FFFFFF?text=Kopi+Arabica+Premium'
    ],
    [
        'id' => 'PRD00006',
        'name' => 'Buku Novel Terbaru',
        'url' => 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400&h=400&fit=crop&crop=center',
        'fallback' => 'https://via.placeholder.com/400x400/27AE60/FFFFFF?text=Buku+Novel+Terbaru'
    ],
    [
        'id' => 'PRD00007',
        'name' => 'Sabun Herbal',
        'url' => 'https://images.unsplash.com/photo-1600857062241-98e5dba7f214?w=400&h=400&fit=crop&crop=center',
        'fallback' => 'https://via.placeholder.com/400x400/2ECC71/FFFFFF?text=Sabun+Herbal'
    ],
    [
        'id' => 'PRD00008',
        'name' => 'Kamera Mirrorless',
        'url' => 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=400&h=400&fit=crop&crop=center',
        'fallback' => 'https://via.placeholder.com/400x400/2C3E50/FFFFFF?text=Kamera+Mirrorless'
    ],
    [
        'id' => 'PRD00009',
        'name' => 'Tas Ransel Vintage',
        'url' => 'https://images.unsplash.com/photo-1547949003-9792a18a2601?w=400&h=400&fit=crop&crop=center',
        'fallback' => 'https://via.placeholder.com/400x400/8B6914/FFFFFF?text=Tas+Ransel+Vintage'
    ],
    [
        'id' => 'PRD00010',
        'name' => 'Coklat Premium',
        'url' => 'https://images.unsplash.com/photo-1511381939415-e44015466834?w=400&h=400&fit=crop&crop=center',
        'fallback' => 'https://via.placeholder.com/400x400/8B4513/FFFFFF?text=Coklat+Premium'
    ]
];

// Fungsi download dengan retry
function downloadImageWithRetry($url, $fallbackUrl, $filename, $uploadDir, $maxRetries = 3) {
    // Cek jika file sudah ada
    $ext = 'jpg';
    $fullPath = $uploadDir . $filename . '.' . $ext;
    
    if (file_exists($fullPath) && filesize($fullPath) > 1000) {
        return ['success' => true, 'path' => $fullPath, 'message' => 'File sudah ada'];
    }
    
    $urls = [$url, $fallbackUrl];
    $lastError = '';
    
    foreach ($urls as $currentUrl) {
        for ($i = 0; $i < $maxRetries; $i++) {
            try {
                // Download dengan cURL
                $ch = curl_init($currentUrl);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_TIMEOUT, 30);
                curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
                curl_setopt($ch, CURLOPT_REFERER, 'https://google.com');
                
                $data = curl_exec($ch);
                $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                $contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
                curl_close($ch);
                
                if ($httpCode == 200 && $data && strlen($data) > 1000) {
                    // Cek apakah ini gambar
                    if (strpos($contentType, 'image') !== false || strlen($data) > 5000) {
                        file_put_contents($fullPath, $data);
                        return ['success' => true, 'path' => $fullPath, 'message' => 'Download berhasil dari: ' . $currentUrl];
                    }
                }
                
                $lastError = "HTTP $httpCode";
                
            } catch (Exception $e) {
                $lastError = $e->getMessage();
            }
            
            // Tunggu sebelum retry
            usleep(500000); // 0.5 detik
        }
    }
    
    // Jika semua gagal, buat placeholder dengan GD
    return createPlaceholderImage($filename, $uploadDir);
}

// Fungsi membuat placeholder dengan GD
function createPlaceholderImage($id, $uploadDir) {
    $fullPath = $uploadDir . $id . '.jpg';
    
    if (!extension_loaded('gd')) {
        return ['success' => false, 'message' => 'GD Library tidak tersedia'];
    }
    
    // Daftar warna untuk setiap produk
    $colors = [
        'PRD00001' => [74, 144, 217],   // Biru
        'PRD00002' => [44, 62, 80],     // Gelap
        'PRD00003' => [231, 76, 60],    // Merah
        'PRD00004' => [52, 73, 94],     // Biru gelap
        'PRD00005' => [139, 69, 19],    // Coklat
        'PRD00006' => [39, 174, 96],    // Hijau
        'PRD00007' => [46, 204, 113],   // Hijau muda
        'PRD00008' => [44, 62, 80],     // Gelap
        'PRD00009' => [139, 105, 20],   // Coklat emas
        'PRD00010' => [139, 69, 19]     // Coklat
    ];
    
    $color = $colors[$id] ?? [100, 100, 100];
    list($r, $g, $b) = $color;
    
    $width = 400;
    $height = 400;
    
    $image = imagecreatetruecolor($width, $height);
    
    // Background
    $bgColor = imagecolorallocate($image, $r, $g, $b);
    imagefill($image, 0, 0, $bgColor);
    
    // Tambahkan pola dekoratif
    $white = imagecolorallocate($image, 255, 255, 255);
    $gray = imagecolorallocate($image, 200, 200, 200);
    
    // Lingkaran dekoratif
    imageellipse($image, $width/2, $height/2, 250, 250, $gray);
    imageellipse($image, $width/2, $height/2, 200, 200, $gray);
    imageellipse($image, $width/2, $height/2, 150, 150, $gray);
    
    // Teks ID Produk
    $textId = "ID: $id";
    $fontSize = 5;
    $textWidth = imagefontwidth($fontSize) * strlen($textId);
    $x = ($width - $textWidth) / 2;
    $y = ($height - imagefontheight($fontSize)) / 2;
    imagestring($image, $fontSize, $x, $y, $textId, $white);
    
    // Simpan
    imagejpeg($image, $fullPath, 90);
    imagedestroy($image);
    
    return ['success' => true, 'path' => $fullPath, 'message' => 'Placeholder dibuat dengan GD'];
}

// Proses download
$downloadResults = [];
$totalSuccess = 0;
$totalFailed = 0;

echo "<div class='progress-bar'><div class='progress-fill' id='progressBar' style='width:0%'>0%</div></div>";

foreach ($products as $index => $product) {
    $id = $product['id'];
    $name = $product['name'];
    $url = $product['url'];
    $fallback = $product['fallback'];
    
    echo "<p><strong>📥 Downloading:</strong> $name ($id)...</p>";
    
    $result = downloadImageWithRetry($url, $fallback, $id, $uploadDir);
    
    if ($result['success']) {
        $totalSuccess++;
        echo "<p class='success'>✅ $id - " . $result['message'] . "</p>";
        
        // Update database
        try {
            $stmt = $pdo->prepare("UPDATE produk SET foto = ? WHERE id_produk = ?");
            $stmt->execute([$id . '.jpg', $id]);
            echo "<p class='info'>📝 Database updated: $id -> " . $id . ".jpg</p>";
        } catch (Exception $e) {
            echo "<p class='error'>⚠️ Gagal update database: " . $e->getMessage() . "</p>";
        }
    } else {
        $totalFailed++;
        echo "<p class='error'>❌ $id - Gagal download: " . ($result['message'] ?? 'Unknown error') . "</p>";
    }
    
    // Update progress
    $percent = round((($index + 1) / count($products)) * 100);
    echo "<script>document.getElementById('progressBar').style.width='$percent%'; document.getElementById('progressBar').innerHTML='$percent%';</script>";
    
    // Flush output
    ob_flush();
    flush();
}

echo "<p><strong>📊 Hasil Download:</strong> ✅ $totalSuccess berhasil | ❌ $totalFailed gagal</p>";
echo "</div>";

// ============================================
// STEP 4: Verifikasi dan Preview
// ============================================
echo "<div class='step'>";
echo "<h3>👀 Step 4: Preview Gambar</h3>";

$files = glob($uploadDir . '*.{jpg,jpeg,png,gif,webp}', GLOB_BRACE);
echo "<p>Total file gambar: " . count($files) . "</p>";

if (count($files) > 0) {
    echo "<div class='product-grid'>";
    foreach ($files as $file) {
        $filename = basename($file);
        $id = pathinfo($filename, PATHINFO_FILENAME);
        echo "<div class='product-item'>";
        echo "<img src='uploads/$filename' alt='$id'>";
        echo "<div class='id'>$id</div>";
        echo "</div>";
    }
    echo "</div>";
}

echo "</div>";

// ============================================
// STEP 5: Verifikasi Database
// ============================================
echo "<div class='step'>";
echo "<h3>🗄️ Step 5: Verifikasi Database</h3>";

try {
    $stmt = $pdo->query("SELECT id_produk, nama_produk, foto FROM produk WHERE foto IS NOT NULL AND foto != ''");
    $productsWithImage = $stmt->fetchAll();
    
    echo "<p>Produk dengan gambar: " . count($productsWithImage) . "</p>";
    
    if (count($productsWithImage) > 0) {
        echo "<table style='width:100%;border-collapse:collapse;'>";
        echo "<tr style='background:#f8f9fa;'><th style='padding:8px;border:1px solid #ddd;'>ID</th><th style='padding:8px;border:1px solid #ddd;'>Nama</th><th style='padding:8px;border:1px solid #ddd;'>Foto</th><th style='padding:8px;border:1px solid #ddd;'>Status</th></tr>";
        foreach ($productsWithImage as $p) {
            $exists = file_exists($uploadDir . $p['foto']);
            $status = $exists ? '✅ Ada' : '❌ Tidak ada';
            $color = $exists ? 'green' : 'red';
            echo "<tr>";
            echo "<td style='padding:8px;border:1px solid #ddd;'><code>{$p['id_produk']}</code></td>";
            echo "<td style='padding:8px;border:1px solid #ddd;'>{$p['nama_produk']}</td>";
            echo "<td style='padding:8px;border:1px solid #ddd;'><code>{$p['foto']}</code></td>";
            echo "<td style='padding:8px;border:1px solid #ddd;color:$color;'>$status</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
} catch (Exception $e) {
    echo "<p class='error'>Error: " . $e->getMessage() . "</p>";
}

echo "</div>";

// ============================================
// STEP 6: Tombol Aksi
// ============================================
echo "<div style='text-align:center;padding:20px;'>";
echo "<h3>✅ Setup Selesai!</h3>";
echo "<p>Sekarang Anda bisa mengakses aplikasi:</p>";
echo "<div style='display:flex;gap:10px;justify-content:center;flex-wrap:wrap;'>";
echo "<a href='pembeli/index.php' class='btn btn-success'>🛍️ Lihat Toko</a>";
echo "<a href='admin/login.php' class='btn btn-warning'>🔑 Login Admin</a>";
echo "<a href='setup_images.php' class='btn'>🔄 Refresh Setup</a>";
echo "</div>";
echo "</div>";

echo "</div>
</body>
</html>";

// Log hasil
$logFile = __DIR__ . '/setup_log.txt';
$logContent = date('Y-m-d H:i:s') . " - Setup Images Completed\n";
$logContent .= "Success: $totalSuccess, Failed: $totalFailed\n";
$logContent .= "----------------------------------------\n";
file_put_contents($logFile, $logContent, FILE_APPEND);
?>